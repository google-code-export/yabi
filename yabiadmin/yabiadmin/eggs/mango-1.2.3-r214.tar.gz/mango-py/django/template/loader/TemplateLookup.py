from mako.lookup import TemplateLookup as makoTemplateLookup
import re, posixpath, os
from mako import exceptions
from django.conf import settings

class TemplateLookup(makoTemplateLookup):
    def get_template(self, uri, debug = False):
        # this is a HACK to get mako to also look back a directory if the template is not found
        
        uri_search_parts = uri.split(os.sep)
                
        for i in range(len(uri_search_parts)):
            uri = os.path.join(*uri_search_parts[i:])
            try:
                if self.filesystem_checks:
                    return self.__check(uri, self.__collection[uri])
                else:
                    return self.__collection[uri]
            except KeyError:
                u = re.sub(r'^\/+', '', uri)
                #print "dirs",self.directories
                for dir in self.directories:
                    srcfile = posixpath.normpath(posixpath.join(dir, u))
                    if os.path.exists(srcfile):
                        return self.__load(srcfile, uri)
         
        raise exceptions.TopLevelLookupException("Cant locate template for uri '%s'" % uri)