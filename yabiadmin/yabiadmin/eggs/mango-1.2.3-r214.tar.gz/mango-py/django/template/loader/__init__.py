#!/usr/bin/env python
# -*- coding: utf-8 -*-
from django.contrib.mako import mako
from TemplateLookup import TemplateLookup
from mako.template import Template
from mako.exceptions import TopLevelLookupException

# the default set of filters
from django.template import defaultfilters

'''
configurations:
    MAKO_TEMPLATE_DIRS:
        A tuple, specify the directories in which to find the mako templates, 
        just like TEMPLATE_DIRS .
        default value is ('mako_templates',)
    MAKO_MODULE_DIR:
        A string, if specified, all of the compiled template module files will be
        stored in this directory.
    MAKO_MODULENAME_CALLABLE:
        A callable, if MAKO_MODULE_DIR is not specified, this will be
        used to determine the filename of compiled template module file.
        See [http://www.makotemplates.org/trac/ticket/14]
        Default to the function `default_module_name`, which
        just appends '.py' to the template filename.
'''

class TemplateDoesNotExist(Exception):
    pass

from django.conf import settings
from django.core.exceptions import ImproperlyConfigured

import os

app_dirs = []
for app in settings.INSTALLED_APPS:
    i = app.rfind('.')
    if i == -1:
        m, a = app, None
    else:
        m, a = app[:i], app[i+1:]
    try:
        if a is None:
            mod = __import__(m, {}, {}, [])
            path = mod.__file__
        elif a in ("admin", "comments"):
            # Special hook for apps that result in circular imports (such as admin and comments).
            mod = __import__(m, {}, {}, [])
            path = os.path.join(os.path.dirname(mod.__file__),'contrib',a,'__init__.py')              # TODO: clean this mess up
        else:
            mod = getattr(__import__(m, {}, {}, [a]), a)
            path = mod.__file__
    except ImportError, e:
        raise ImproperlyConfigured, 'ImportError %s: %s' % (app, e.args[0])

    app_dirs.append(os.path.dirname(path))

app_template_dirs = []
for app_dir in app_dirs:
    template_dir = os.path.join(app_dir, 'templates')
    if os.path.isdir(template_dir):
        app_template_dirs.append(template_dir)

template_dirs = getattr(settings, 'TEMPLATE_DIRS', None) or ('mako_templates',)
template_dirs += tuple(app_template_dirs)

def default_module_name(filename, uri):
    '''
    Will store module files in the same directory as the corresponding template files.
    detail about module_name_callable, go to 
    http://www.makotemplates.org/trac/ticket/14
    '''
    return filename+'.py'

module_dir = getattr(settings, 'MAKO_MODULE_DIR', None)

if module_dir:
    lookup = TemplateLookup(directories=template_dirs,
            module_directory=module_dir)
else:
    module_name_callable = getattr(settings, 'MAKO_MODULENAME_CALLABLE', None)

    if callable(module_name_callable):
        lookup = TemplateLookup(directories=template_dirs,
                modulename_callable=module_name_callable)
    else:
        lookup = TemplateLookup(directories=template_dirs,
                modulename_callable=default_module_name)

def select_template(template_name_list):
    for template_name in template_name_list:
        try:
            return lookup.get_template(template_name)
        except TopLevelLookupException:
            pass

    raise TemplateDoesNotExist, 'mako templates: '+', '.join(template_name_list)



def get_template(template_name):
    """Returns the template object for the given template"""
    try:
        return lookup.get_template(template_name)
    except TopLevelLookupException, tle:
        raise TemplateDoesNotExist, 'mako templates: '+template_name

# bolt in csrf template tag as filter
from django.template.defaulttags import CsrfTokenNode
def csrf_tag(token):
    return CsrfTokenNode().render({'csrf_token':token})

def trans(inp):
    return inp

def url(var):
    return var

#def load_template_tags(tagset):
    ## get the name of the template file that called us
    #import inspect
    #c_frame = inspect.currentframe().f_back
    #c_vars = c_frame.f_globals
    #c_locals = c_frame.f_locals
    #c_file = c_vars['__file__']
    #c_template_uri = c_vars['_template_uri']
    #c_template_filename = c_vars['_template_filename']
    
    ## now take the template filename and remove the template uri from the end to generate the bast path
    #assert c_template_filename.endswith(c_template_uri)
    #basepath = c_template_filename[:-len(c_template_uri)]
    
    ## cut the end off
    #truncate = 'templates/'
    #assert basepath.endswith(truncate)
    #basepath = basepath[:-len(truncate)]
    
    ## add the templatetags
    #templatetags = os.path.join(basepath,"templatetags")
    
    ## is there a tagset file in here
    #file = os.path.join(templatetags,"%s.py"%tagset)
    #assert os.path.exists(file)
    
    ## we are gonna import this py file into the calling frames namespace.
    #locs = {}
    #globs = {}
    #execfile(file, globs, locs)
    
    #for k in locs:
        #if k != 'Library' and k != 'register':
            #print k,"=>",locs[k]
            #c_locals['context']._data[k]=locs[k]
    
    ##parentself = c_frame.f_back.f_locals['self']
    ##parentcontext = parentself.context
    
    ##for k in locs:
        ##if k != 'Library' and k != 'register':
            ##print k,"=>",locs[k]
            ##parentcontext[k]=locs[k]
    
    ##self = c_frame.f_back.f_locals['self']
    
    ##assert False
    ##print "="*80
    ##print c_frame.f_back.f_locals['self']

def template_add_tags(dictionary, module):
    """Adds a whole bunch of tags to the context. pass in a dictionary... and returns a new dictionary with the tags added"""
    newdict = dictionary.copy()
    for key in dir(module):
        newdict[key] = getattr(module,key)
    return newdict

from django.contrib.mako.mako import filters
from django.utils import html, text
from django.templatetags import i18n
#standard_tags = template_add_tags(template_add_tags(template_add_tags({},filters),html),i18n)
standard_tags = {
    'trans':trans,
    'url':url,
    #'load_template_tags':load_template_tags,
    'LANGUAGE_CODE':'en',
}

default_list = ['capfirst', 'center', 'csrf_tag', 'cut', 'date', 'default', 'default_if_none', 'dictsort', 'dictsortreversed', 'divisibleby', 'escape', 'escapejs', 'filesizeformat', 'first', 'fix_ampersands', 'floatformat', 'force_escape', 'get_digit', 'iriencode', 'join', 'last', 'length', 'length_is', 'linebreaks', 'linebreaksbr', 'linenumbers', 'ljust', 'lower', 'make_list', 'phone2numeric', 'pluralize', 'pprint', 'removetags', 'random', 'rjust', 'safe', 'safeseq', 'slugify', 'stringformat', 'striptags', 'time', 'timesince', 'timeuntil', 'title', 'truncatewords', 'truncatewords_html', 'unordered_list', 'upper', 'urlencode', 'urlize', 'urlizetrunc', 'wordcount', 'wordwrap', 'yesno']

for name in default_list:
    standard_tags[name] = getattr(defaultfilters,name)
    
standard_tags['slice']=defaultfilters.slice_
    
standard_tags = template_add_tags(template_add_tags(template_add_tags(template_add_tags(standard_tags,filters),html),i18n),text)


def render_to_string(template_name, dictionary=None, context_instance=None):
    """Loads template_name and renders it with the given dictionary as context.
    The template_name may be a string to load a single template using get_template,
    or it may be a tuple to use select_template to find one of the templates in the list.
    returns a string.
    """
    if isinstance(template_name, (list, tuple)):
        template = select_template(template_name)
    else:
        template = get_template(template_name)

    dictionary = dictionary or {}
    context_instance = context_instance or {}
    
    if context_instance is not None:
        context_instance.update(dictionary)
    data = {}
    data.update(standard_tags)
    try:
        [data.update(d) for d in context_instance]
    except ValueError, ve:
        data.update(context_instance)
    return template.render_unicode(**data)
    
def render_to_response(template_name, dictionary=None, context_instance=None):
    if isinstance(template_name, (list, tuple)):
        template = select_template(template_name)
    else:
        template = get_template(template_name)

    dictionary = dictionary or {}
    if context_instance is None:
        context_instance = RequestContext(dictionary)
    else:
        context_instance.update(dictionary)
    data = {}
    data.update(standard_tags)
    try:
        [data.update(d) for d in context_instance]
    except ValueError, ve:
        data.update(context_instance)
    return HttpResponse(template.render_unicode(**data))
    
def render_mako_to_string(template_name, **kwargs):
    if isinstance(template_name, (list, tuple)):
        template = select_template(template_name)
    else:
        template = get_template(template_name)
    
    return template.render_unicode(**kwargs)

