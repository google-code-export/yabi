<%inherit file="gis/admin/openlayers.js" />
<%def name="base_layer()">new OpenLayers.Layer.OSM.Mapnik("OpenStreetMap (Mapnik)");</%def>
