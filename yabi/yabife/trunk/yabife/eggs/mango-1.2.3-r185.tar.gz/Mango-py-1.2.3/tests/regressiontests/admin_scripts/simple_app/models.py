from admin_scripts.complex_app.models.bar import Bar
