"""
Unit-tests for the dispatch project
"""

from test_saferef import *
from test_dispatcher import *
