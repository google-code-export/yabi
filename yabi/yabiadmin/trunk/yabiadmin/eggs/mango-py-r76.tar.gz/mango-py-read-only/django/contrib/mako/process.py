#!/usr/bin/env python

# This is a processing script to rename the imports so they are under django.contrib

import re, os

re_from = re.compile("\smako")
to = " django.contrib.mako.mako"

if __name__=="__main__":
    
    def walker(args, directory, files):
        for file in [filename for filename in files if filename.endswith(".py")]:
            path = os.path.join(directory,file)
            
            data = open(path).read()
                
            writer = open(path,'w')
            writer.write(re_from.sub( to, data))
            writer.close()
        
    os.path.walk(".",walker,())