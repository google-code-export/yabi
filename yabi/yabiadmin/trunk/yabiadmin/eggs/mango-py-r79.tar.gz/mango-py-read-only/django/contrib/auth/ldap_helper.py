import ldap
import django
from django.contrib.auth.models import User

#for LDAP search results helper
import ldif
from StringIO import StringIO
from ldap.cidict import cidict

from django.conf import settings

class LDAPSearchResult(object):
    """A class to model LDAP results.
    """
    dn = ''

    def __init__(self, entry_tuple):
        """Create a new LDAPSearchResult object."""
        #print 'Creating LDAPSearchResult item...'
        (dn, attrs) = entry_tuple
        if dn:
            self.dn = dn
        else:
            return

        self.attrs = cidict(attrs)

    def get_attributes(self):
        """Get a dictionary of all attributes.
        get_attributes()->{'name1':['value1','value2',...], 'name2: [value1...]}
        """
        return self.attrs

    def set_attributes(self, attr_dict):
        """Set the list of attributes for this record.

        The format of the dictionary should be string key, list of string 
        values. e.g. {'cn': ['M Butcher','Matt Butcher']}

        set_attributes(attr_dictionary)
        """
        self.attrs = cidict(attr_dict)

    def has_attribute(self, attr_name):
        """Returns true if there is an attribute by this name in the
        record.

        has_attribute(string attr_name)->boolean
        """
        return self.attrs.has_key( attr_name )

    def get_attr_values(self, key):
        """Get a list of attribute values.
        get_attr_values(string key)->['value1','value2']
        """
        return self.attrs[key]

    def get_attr_names(self):
        """Get a list of attribute names.
        get_attr_names()->['name1','name2',...]
        """
        return self.attrs.keys()

    def get_dn(self):
        """Get the DN string for the record.
        get_dn()->string dn
        """
        return self.dn

    def pretty_print(self):
        """Create a nice string representation of this object.

        pretty_print()->string
        """
        str = "DN: " + self.dn + "\n"
        for a, v_list in self.attrs.iteritems():
            str = str + "Name: " + a + "\n"
            for v in v_list:
                str = str + "  Value: " + v + "\n"
        str = str + "========"
        return str

    def to_ldif(self):
        """Get an LDIF representation of this record.

        to_ldif()->string
        """
        out = StringIO()
        ldif_out = ldif.LDIFWriter(out)
        ldif_out.unparse(self.dn, self.attrs)
        return out.getvalue()


class LDAPHandler(object):
    def __init__(self, username=None, password=None):
        '''This class makes use of the 'settings' module, which should be accessible from the current scope.'''
        try:
            #Check to see if this is a dev server.
            if settings.DEV_SERVER:
                ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_NEVER)
            #initialise LDAP server connection
            self.l = ldap.initialize(settings.AUTH_LDAP_SERVER)
            self.l.protocol_version = ldap.VERSION3
            if (username is None):
                #bind using simple auth or Kerberos if available
                self.l.simple_bind_s()
                if settings.DEBUG:
                    print 'Anonymous bind OK'
            else:
                assert False, "Authenticated binds not presently supported"
        except ldap.LDAPError, e:
            print "Ldap Error:\n%s" % e
            return None

        #Otherwise, set a few variables for later use
        self.BASE = settings.AUTH_LDAP_BASE
        self.GROUP = settings.AUTH_LDAP_GROUP
        self.GROUP_BASE = settings.AUTH_LDAP_GROUP_BASE
        self.SERVER = settings.AUTH_LDAP_SERVER
        self.GROUPOC = 'groupofuniquenames'
        self.USEROC = 'inetorgperson'
        self.MEMBERATTR = 'uniqueMember'
        self.USERDN = 'ou=People'
  
    def get_search_results(self, results):
        """Given a set of results, return a list of LDAPSearchResult objects.
        """
        res = []

        if type(results) == tuple and len(results) == 2 :
                (code, arr) = results
        elif type(results) == list:
                arr = results

        if len(results) == 0:
                return res

        for item in arr:
                res.append( LDAPSearchResult(item) )

        return res

    def ldap_query(self, base=None, scope=ldap.SCOPE_SUBTREE, filter="", rattrs=None, timeout=0):
        '''base is the ldap base to search on
           scope is the scope of the search (depth of descendant searches etc)
           userfilter is the user supplied filter information ( a string)
           rattrs is the format of the result set
        '''
        if base is None:
            base = self.BASE

        retval = []
        try:
            if settings.DEBUG:
                print 'LDAP Query: ', base, scope, filter, rattrs
            #result_id = self.l.search(base, scope, filter, rattrs)            
            #result_type, result_data = self.l.result(result_id, timeout)
            result_data = self.l.search_s(base, scope, filter, rattrs)
            retval = self.get_search_results(result_data)
            #for val in retval:
            #    print val.pretty_print()
        except Exception, e:#ldap.LDAPError, error_message:
            print 'LDAP Query Error: ', str(e)
            #print 'LDAP Query Error: ', error_message           
        return retval
    
    def ldap_list_groups(self):
        groupdn = self.GROUP_BASE 
        userfilter = '(objectClass=%s)' % (self.GROUPOC)
        result_data = self.ldap_query(base=groupdn, filter=userfilter)
        groups = []
        for result in result_data:
            #print result.pretty_print()
            for g in result.get_attr_values('cn'):
                groups.append(g)
        return groups
        
 
    def ldap_get_user_details(self, username):
        #Get application user details (only users in the application's LDAP tree) 
        searchbase = 'ou=NEMA, ou=People, dc=ccg, dc=murdoch, dc=edu, dc=au'
        result_data = self.ldap_query(base=searchbase, filter = "uid=%s" % (username) )            
        if len(result_data) > 0:
            #userdetails = {}
            #for record in result_data[0]:
            #    print 'ldap record: ', record.pretty_print()
            #r = result_data[0][1]
            #for key in r.keys():
            #    if len(r[key]) == 1:
            #        userdetails[key] = r[key][0]
            #    else:
            #        userdetails[key] = r[key]
            #
            #TODO: merge in group data
            userdetails = result_data[0].get_attributes()
            a = self.ldap_get_user_groups(username)
            if settings.DEBUG:
                print 'The User Groups were:', a

            #TODO: merge the groups package with the userdetails.
                
            return userdetails

        else:
            if settings.DEBUG:
                print 'ldap_get_user_details returned no results.'
            return []  


    def ldap_add_group(self, groupname):
        groupname = strip(groupname)
        
        pass

    def ldap_rename_group(self, oldname, newname):
        #print 'ldap_rename_group'
        pass
        

    def ldap_get_user_groups(self, username):
        
        #print 'ldap_get_user_groups'
        udn = self.ldap_get_user_dn(username)
        if udn is None:
            return None
        
        f = '(&(objectClass=%s)(%s=%s))' % (self.GROUPOC, self.MEMBERATTR, udn)    
        #f = '(&(objectclass=groupofuniquenames)(uniquemember=uid=bpower@ccg.murdoch.edu.au,ou=NEMA,ou=People,dc=ccg,dc=murdoch,dc=edu,dc=au))'
        result_data = self.ldap_query(base=self.GROUP_BASE,filter=f)            
        #result_data = self.ldap_query(base='dc=ccg,dc=murdoch,dc=edu,dc=au', filter=f)            
        groups = []
        for result in result_data:
            #print '***', result.pretty_print()
            for g in result.get_attr_values('cn'):
                groups.append(g) 
        
        if len(groups) == 0 and settings.DEBUG:
            print 'ldap_get_user_groups returned no results.'
      
        return groups  
            
    def ldap_get_user_dn(self, username):
        #print 'ldap_get_user_dn'
        result_data = self.ldap_query(filter='uid=%s' % (username))
        if len(result_data) > 0:
            dn = result_data[0].get_dn()
            if settings.DEBUG:
                print 'User DN found as: ', dn
            return dn
        else:
            print 'Username not found!'        
            return None            

    def ldap_list_users(self, searchGroup):
        '''expects searchGroup to be a list of groups to search
           fetches an array of user detail dictionaries'''
        #print 'ldap_list_users'
        #TODO: if no group name is passed in, use a default?

        users = []
        for groupname in searchGroup:
            #TODO: search for all users in the group
            filter = 'cn=%s' % (groupname)
            userlist = self.ldap_search_users(filter = filter, base=self.GROUP_BASE)
            for user in userlist:
                users.append(user) 
        #print 'USERS:', users     

        #TODO: merge the results

        return users

    def ldap_search_users(self, base, filter):
        '''returns a list of users, each user being a dict'''
        #print 'ldap_search_users'
        results = self.ldap_query(filter=filter, base=base)
       
        users = []
        for result in results:
            #print 'RESULTS', result.pretty_print()
            if result.has_attribute('uniquemember'):
                userresults = result.get_attr_values('uniquemember')
                #print 'USERRESULTS: ', userresults
                for user in userresults:
                    #print 'USER: ', user
                    #retrieve the details of this useer.
                    prefix, uname =user.split('=', 1)
                    uname, rest = uname.split(',', 1)
                    #print uname
                    userdetails = self.ldap_get_user_details(uname)
                    #print userdetails.pretty_print()
                    users.append(userdetails)
        return users