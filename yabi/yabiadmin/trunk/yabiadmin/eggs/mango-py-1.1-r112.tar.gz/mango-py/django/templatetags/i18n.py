def trans(text):
    """
    translate a string... TODO
    """
    return text