from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 5
_modified_time = 1287472575.585876
_template_filename='templates/comments/comment_notification_email.txt'
_template_uri='comments/comment_notification_email.txt'
_template_cache=cache.Cache(__name__, _modified_time)
_source_encoding=None
_exports = []


def render_body(context,**pageargs):
    context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        comment = context.get('comment', UNDEFINED)
        content_object = context.get('content_object', UNDEFINED)
        __M_writer = context.writer()
        # SOURCE LINE 1
        __M_writer(u'A comment has been posted on ')
        __M_writer(unicode(content_object))
        __M_writer(u'.\nThe comment reads as follows:\n')
        # SOURCE LINE 3
        __M_writer(unicode(comment))
        __M_writer(u'\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


