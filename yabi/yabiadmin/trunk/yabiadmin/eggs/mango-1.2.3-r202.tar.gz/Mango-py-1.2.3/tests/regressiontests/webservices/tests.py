from admin import *
from django.conf import settings
from django.contrib.auth.models import User
from django.contrib import introspect
from django.test import TestCase
from json import loads
from models import *


class ExtTest(TestCase):
    fixtures = [
        "basic.json",
        "many-to-many.json",
        "parent-child.json",
        "users.json",
    ]

    def setUp(self):
        self.client.login(username="admin", password="admin")

    def tearDown(self):
        self.client.logout()

    def assertJSON(self, response, msg="Content-Type isn't JSON"):
        self.assertTrue((response.status_code >= 200 and response.status_code <= 299), "Status isn't 2XX")
        self.assertTrue("json" in response["Content-Type"], msg)

    def get_field(self, metadata, name):
        for field in metadata["fields"]:
            if field["name"] == name:
                return field

        raise KeyError
        
    def test_basic_delete(self):
        response = self.client.delete("/webservices/admin/webservices/basic/ext/json/1")
        self.assertJSON(response)

        json = loads(response.content)

        self.assertTrue(json["success"], "Success isn't true")

        # See if the object was actually deleted.
        self.assertRaises(Basic.DoesNotExist, lambda: Basic.objects.get(id=1))

    def test_basic_get(self):
        response = self.client.get("/webservices/admin/webservices/basic/ext/json")
        self.assertJSON(response)

        json = loads(response.content)

        # Check metadata.
        self.assertEqual(json["metaData"]["idProperty"], "id", "idProperty incorrect")
        self.assertEqual(len(json["metaData"]["fields"]), 2, "Incorrect number of fields")

        id = self.get_field(json["metaData"], "id")
        self.assertEqual(id["type"], "int", "id type incorrect")

        name = self.get_field(json["metaData"], "name")
        self.assertEqual(name["type"], "auto", "name type incorrect")

        # Check content.
        self.assertEqual(len(json["rows"]), 1, "JSON contains multiple objects")

        row = json["rows"][0]
        self.assertEqual(row["id"], "1", "id incorrect")
        self.assertEqual(row["name"], "Foo", "name incorrect")
        
    def test_basic_post(self):
        json = """
            {
                "data": {
                    "name": "Quux"
                }
            }
        """

        response = self.client.post("/webservices/admin/webservices/basic/ext/json", data=json, content_type="application/json; charset=UTF-8")
        self.assertJSON(response)

        json = loads(response.content)

        self.assertTrue(json["success"], "Success isn't true")
        self.assertEqual(json["data"]["name"], "Quux", "name incorrect")

        # See if the object was actually created.
        o = Basic.objects.get(name="Quux")
        self.assertEqual(o.id, int(json["data"]["id"]), "ID doesn't match")

    def test_basic_put(self):
        json = """
            {
                "data": {
                    "name": "Updated",
                    "id": 1
                }
            }
        """

        response = self.client.put("/webservices/admin/webservices/basic/ext/json/1", data=json, content_type="application/json; charset=UTF-8")
        self.assertJSON(response)

        json = loads(response.content)

        self.assertTrue(json["success"], "Success isn't true")
        self.assertEqual(json["data"]["name"], "Updated", "name incorrect")

        # See if the object was actually created.
        o = Basic.objects.get(id=1)
        self.assertEqual(o.name, "Updated", "Name doesn't match")

    def test_fail_delete(self):
        response = self.client.delete("/webservices/admin/webservices/basic/ext/json/100")
        self.assertEqual(response.status_code, 404, "Status is not 404")

    def test_fail_get(self):
        response = self.client.get("/webservices/admin/webservices/basic/ext/json?id=100")
        self.assertJSON(response)

        json = loads(response.content)
        self.assertEqual(len(json["rows"]), 0, "Row count is non-zero")

    def test_fail_post(self):
        json = """
            {
                "data": {
                    "name": "Updated",
                    "badkey": "foo"
                }
            }
        """

        response = self.client.post("/webservices/admin/webservices/basic/ext/json", data=json, content_type="application/json; charset=UTF-8")
        self.assertEqual(response.status_code, 400, "Status is not 400")

    def test_fail_put(self):
        json = """
            {
                "data": {
                    "name": "Updated",
                    "id": 100
                }
            }
        """

        response = self.client.put("/webservices/admin/webservices/basic/ext/json/100", data=json, content_type="application/json; charset=UTF-8")
        self.assertEqual(response.status_code, 404, "Status is not 404")

    def test_fail_put_atomicity(self):
        json = """
            {
                "data": {
                    "name": "Updated",
                    "id": "foo"
                }
            }
        """

        response = self.client.put("/webservices/admin/webservices/basic/ext/json/1", data=json, content_type="application/json; charset=UTF-8")
        self.assertEqual(response.status_code, 400, "Status is not 400")

        o = Basic.objects.get(id=1)
        self.assertEqual(o.name, "Foo", "Name was changed")

    def test_filter(self):
        # Add another object to filter against.
        o = Basic()
        o.name = "Bar"
        o.save()

        response = self.client.get("/webservices/admin/webservices/basic/ext/json?name__iexact=bar")
        self.assertJSON(response)

        json = loads(response.content)
        self.assertEqual(len(json["rows"]), 1, "Row count is not 1")
        self.assertEqual(int(json["rows"][0]["id"]), o.id, "Returned row is not the expected row")

    def test_foreign_get(self):
        response = self.client.get("/webservices/admin/webservices/child/ext/json?id=1")
        self.assertJSON(response)

        json = loads(response.content)
        self.assertEqual(len(json["rows"]), 1, "Row count is not 1")
        self.assertEqual(int(json["rows"][0]["id"]), 1, "Returned row is not the expected row")
        self.assertEqual(int(json["rows"][0]["parent"]), 1, "Returned row is not the expected row")

    def test_foreign_post(self):
        json = """
            {
                "data": {
                    "parent": 2
                }
            }
        """

        response = self.client.post("/webservices/admin/webservices/child/ext/json", data=json, content_type="application/json; charset=UTF-8")
        self.assertJSON(response)

        json = loads(response.content)

        o = Child.objects.get(id=int(json["data"]["id"]))
        self.assertEqual(o.parent.id, 2, "Parent ID is not 2")

    def test_foreign_put(self):
        json = """
            {
                "data": {
                    "parent": 2
                }
            }
        """

        response = self.client.put("/webservices/admin/webservices/child/ext/json/1", data=json, content_type="application/json; charset=UTF-8")
        self.assertJSON(response)

        o = Child.objects.get(id=1)
        self.assertEqual(o.parent.id, 2, "Parent ID is not 2")

    def test_foreign_put_fail(self):
        json = """
            {
                "data": {
                    "parent": 3
                }
            }
        """

        response = self.client.put("/webservices/admin/webservices/child/ext/json/1", data=json, content_type="application/json; charset=UTF-8")
        self.assertEqual(response.status_code, 500, "Status is not 500")

        o = Child.objects.get(id=1)
        self.assertEqual(o.parent.id, 1, "Parent ID is not 1")

    def test_many_get(self):
        o = ManyB.objects.get(id=1)

        response = self.client.get("/webservices/admin/webservices/manyb/ext/json?id=1")
        self.assertJSON(response)

        json = loads(response.content)
        self.assertEqual(len(json["rows"]), 1, "Row count is not 1")
        self.assertEqual(int(json["rows"][0]["id"]), 1, "Returned row is not the expected row")
        self.assertEqual(json["rows"][0]["manya"], [a.id for a in o.manya.all()], "Returned many to many values unexpected")

    def test_many_post(self):
        json = """
            {
                "data": {
                    "manya": [1, 2]
                }
            }
        """

        response = self.client.post("/webservices/admin/webservices/manyb/ext/json", data=json, content_type="application/json; charset=UTF-8")
        self.assertJSON(response)

        json = loads(response.content)

        o = ManyB.objects.get(id=int(json["data"]["id"]))
        self.assertEqual(o.manya.count(), 2, "Unexpected number of relations")

    def test_many_put(self):
        json = """
            {
                "data": {
                    "manya": [1]
                }
            }
        """

        response = self.client.put("/webservices/admin/webservices/manyb/ext/json/1", data=json, content_type="application/json; charset=UTF-8")
        self.assertJSON(response)

        json = loads(response.content)

        o = ManyB.objects.get(id=1)
        self.assertEqual(o.manya.count(), 1, "Unexpected number of relations")
        self.assertEqual(o.manya.all()[0].id, 1, "ManyA ID unexpected")

    def test_sort(self):
        # Add another object to sort with.
        o = Basic()
        o.name = "Bar"
        o.save()

        response = self.client.get("/webservices/admin/webservices/basic/ext/json?sort=name&dir=ASC")
        self.assertJSON(response)

        json = loads(response.content)
        self.assertEqual(len(json["rows"]), 2, "Row count is not 2")
        self.assertEqual(json["rows"][0]["name"], "Bar", "Returned row is not the expected row")
        self.assertEqual(json["rows"][1]["name"], "Foo", "Returned row is not the expected row")

        response = self.client.get("/webservices/admin/webservices/basic/ext/json?sort=name&dir=DESC")
        self.assertJSON(response)

        json = loads(response.content)
        self.assertEqual(len(json["rows"]), 2, "Row count is not 2")
        self.assertEqual(json["rows"][0]["name"], "Foo", "Returned row is not the expected row")
        self.assertEqual(json["rows"][1]["name"], "Bar", "Returned row is not the expected row")
