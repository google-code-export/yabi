from django.db import models


class Basic(models.Model):
    name = models.CharField(max_length=50)


class Parent(models.Model):
    pass


class Child(models.Model):
    parent = models.ForeignKey(Parent)


class ManyA(models.Model):
    pass


class ManyB(models.Model):
    manya = models.ManyToManyField(ManyA)
